# Bible Inspiration Chat

A conversational AI that helps people find spiritual encouragement and relevant scripture based on their life situations. Built with a modular architecture that supports multiple LLM backends.

## 🌟 Features

- **AI-Powered Conversations**: Natural dialogue grounded in Biblical text
- **Semantic Scripture Search**: Find relevant verses based on meaning, not just keywords
- **Configurable LLM Backend**: Start with Ollama (local), switch to Claude or OpenAI later
- **REST API**: Ready for mobile app development
- **Modern Web Interface**: Clean, responsive chat UI

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Frontend (Next.js)                      │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                    Backend API (FastAPI)                     │
│  ┌─────────────┐  ┌─────────────┐  ┌────────────────────┐   │
│  │ LLM Provider │  │ Scripture   │  │ Embedding          │   │
│  │ (Ollama/    │  │ Search      │  │ Provider           │   │
│  │  Claude)    │  │ Service     │  │                    │   │
│  └─────────────┘  └─────────────┘  └────────────────────┘   │
└───────┬─────────────────┬─────────────────┬─────────────────┘
        │                 │                 │
┌───────▼───────┐ ┌───────▼───────┐ ┌───────▼───────┐
│    Ollama     │ │  PostgreSQL   │ │   pgvector    │
│ (Local LLM)   │ │ (Bible Data)  │ │ (Embeddings)  │
└───────────────┘ └───────────────┘ └───────────────┘
```

## 🚀 Quick Start

### Prerequisites

- Docker & Docker Compose
- Ollama installed locally (for self-hosted LLM)
- 8GB+ GPU (recommended) or CPU with 16GB+ RAM

### 1. Clone and Setup

```bash
cd bible-chat
cp api/.env.example api/.env  # Create env file (optional)
```

### 2. Pull Required Ollama Models

```bash
# Pull the LLM model
ollama pull llama3:8b

# Pull the embedding model
ollama pull nomic-embed-text
```

### 3. Start Services

```bash
# Start all services
docker-compose up -d

# Watch logs
docker-compose logs -f
```

### 4. Load Bible Data

```bash
# Install Python dependencies locally for scripts
cd scripts
pip install httpx asyncpg sqlalchemy

# Load Bible into database
python load_bible.py

# Generate embeddings (takes ~30-60 minutes)
python create_embeddings.py
```

### 5. Access the App

- **Web App**: http://localhost:3000
- **API Docs**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/health

## 📁 Project Structure

```
bible-chat/
├── docker-compose.yml      # Container orchestration
├── api/                    # FastAPI backend
│   ├── main.py            # Application entry point
│   ├── config.py          # Configuration settings
│   ├── providers/         # LLM provider abstraction
│   │   ├── base.py       # Provider interface
│   │   ├── ollama.py     # Ollama implementation
│   │   ├── claude.py     # Claude implementation
│   │   └── factory.py    # Provider factory
│   ├── scripture/         # Bible data layer
│   │   ├── models.py     # Database models
│   │   ├── database.py   # DB connection
│   │   ├── repository.py # Data queries
│   │   └── search.py     # Semantic search
│   ├── chat/              # Chat logic
│   │   ├── service.py    # Chat orchestration
│   │   └── prompts.py    # System prompts
│   └── routes/            # API endpoints
├── frontend/              # Next.js web app
│   └── src/
│       ├── app/          # Pages
│       ├── components/   # UI components
│       └── lib/          # API client
├── scripts/               # Utility scripts
│   ├── load_bible.py     # Load Bible data
│   └── create_embeddings.py # Generate vectors
└── data/                  # Local data storage
```

## ⚙️ Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `LLM_PROVIDER` | `ollama` | LLM backend: `ollama`, `claude`, `openai` |
| `LLM_MODEL` | `llama3:8b` | Model name |
| `OLLAMA_HOST` | `http://localhost:11434` | Ollama server URL |
| `EMBEDDING_MODEL` | `nomic-embed-text` | Embedding model |
| `DATABASE_URL` | `postgresql://...` | PostgreSQL connection |
| `ANTHROPIC_API_KEY` | - | For Claude provider |

### Switching LLM Providers

To use Claude instead of Ollama:

```bash
# In docker-compose.yml or .env
LLM_PROVIDER=claude
LLM_MODEL=claude-sonnet-4-20250514
ANTHROPIC_API_KEY=your-api-key-here
```

## 🔌 API Reference

### Chat Endpoints

#### POST `/api/v1/chat`
Send a message and receive a Bible-grounded response.

```json
{
  "message": "I'm feeling anxious about my future",
  "conversation_history": [],
  "include_search": true
}
```

#### POST `/api/v1/chat/stream`
Stream a response in real-time (Server-Sent Events).

### Scripture Endpoints

#### GET `/api/v1/scripture/search?q={query}`
Semantic search for relevant verses.

#### GET `/api/v1/scripture/verse/{book}/{chapter}/{verse}`
Get a specific verse.

#### GET `/api/v1/scripture/chapter/{book}/{chapter}`
Get all verses in a chapter.

## 🧪 Development

### Running Without Docker

```bash
# Terminal 1: Start PostgreSQL and Ollama
ollama serve

# Terminal 2: Start API
cd api
pip install -r requirements.txt
uvicorn main:app --reload

# Terminal 3: Start Frontend
cd frontend
npm install
npm run dev
```

### Running Tests

```bash
cd api
pytest
```

## 🗺️ Roadmap

- [ ] Mobile app (React Native)
- [ ] User accounts and saved conversations
- [ ] Reading plans integration
- [ ] Audio Bible support
- [ ] Multiple Bible translations
- [ ] Community features (shared verses)

## 📝 License

This project is for educational and inspirational purposes. Bible text uses the KJV (public domain).

## 🙏 Contributing

Contributions welcome! Please read our contributing guidelines first.

---

*"Your word is a lamp for my feet, a light on my path."* - Psalm 119:105
